using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace StudentMvc.Controllers
{
 public class ApiTokenController : Controller
 {
 private readonly IHttpClientFactory _factory;
 public ApiTokenController(IHttpClientFactory factory)
 {
 _factory = factory;
 }

 public async Task<IActionResult> GetToken()
 {
 var client = _factory.CreateClient("StudentApi");
 var response = await client.PostAsJsonAsync("api/auth/login", new { Username = "admin", Password = "password" });
 if (!response.IsSuccessStatusCode) return StatusCode((int)response.StatusCode);
 var obj = await response.Content.ReadFromJsonAsync<JsonElement>();
 if (obj.TryGetProperty("token", out var t))
 {
 var token = t.GetString();
 // store token in session or cookie for demo
 HttpContext.Response.Cookies.Append("ApiToken", token ?? string.Empty);
 return RedirectToAction("Index", "Home");
 }
 return BadRequest();
 }
 }
}