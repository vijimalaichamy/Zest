using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using StudentModel = Student.Models.Student;

namespace StudentMvc.Controllers
{
    public class HomeController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public HomeController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        private HttpClient CreateAuthorizedClient()
        {
            var client = _httpClientFactory.CreateClient("StudentApi");
            if (Request.Cookies.TryGetValue("ApiToken", out var token))
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return client;
        }

        public async Task<IActionResult> Index()
        {
            var client = _httpClientFactory.CreateClient("StudentApi");
            var students = await client.GetFromJsonAsync<IEnumerable<StudentModel>>("api/students");
            return View(students);
        }

        public IActionResult Create() => View(new StudentModel());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(StudentModel student)
        {
            if (!ModelState.IsValid) return View(student);
            var client = CreateAuthorizedClient();
            var response = await client.PostAsJsonAsync("api/students", student);
            if (response.IsSuccessStatusCode) return RedirectToAction(nameof(Index));
            ModelState.AddModelError(string.Empty, "Failed to create student. Are you logged in?");
            return View(student);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var client = CreateAuthorizedClient();
            var student = await client.GetFromJsonAsync<StudentModel>($"api/students/{id}");
            if (student is null) return NotFound();
            return View(student);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, StudentModel student)
        {
            if (!ModelState.IsValid) return View(student);
            var client = CreateAuthorizedClient();
            var response = await client.PutAsJsonAsync($"api/students/{id}", student);
            if (response.IsSuccessStatusCode) return RedirectToAction(nameof(Index));
            ModelState.AddModelError(string.Empty, "Failed to update student.");
            return View(student);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var client = CreateAuthorizedClient();
            await client.DeleteAsync($"api/students/{id}");
            return RedirectToAction(nameof(Index));
        }
    }
}