ASP.NET MVC client project that calls the Student API via HttpClient.

To run:
1. Start the Student API project (Student) on e.g. https://localhost:7001
2. Open the StudentMvc project and run it.

This sample uses a simple cookie to store a JWT after calling `/api/auth/login` from `ApiTokenController.GetToken`.

Note: Update the StudentApi BaseUrl in appsettings.json if needed.