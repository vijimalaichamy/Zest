using System.ComponentModel.DataAnnotations;

namespace Student.Models
{
    public class Student
    {
        public Student()
        {
            CreatedDate = DateTime.UtcNow;
        }

        public int Id { get; set; }

        [Required]
        [StringLength(200)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        public int? Age { get; set; }

        [StringLength(200)]
        public string? Course { get; set; }

        public DateTime CreatedDate { get; set; }
    }
}