Use 'dotnet ef migrations add Initial' and 'dotnet ef database update' to create migrations and update the SQLite database. This repository includes EF Core packages.

If you run locally, ensure you have the 'dotnet-ef' tool installed: 'dotnet tool install --global dotnet-ef' and run commands from the project directory.