-- SQL script to create the Students table (SQLite)
-- Columns: Id, Name, Email, Age, Course, CreatedDate

CREATE TABLE IF NOT EXISTS Students (
 Id INTEGER PRIMARY KEY AUTOINCREMENT,
 Name TEXT NOT NULL,
 Email TEXT NOT NULL UNIQUE,
 Age INTEGER,
 Course TEXT,
 CreatedDate TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

-- Example: insert seed data
-- INSERT INTO Students (Name, Email, Age, Course) VALUES ('John Doe', 'john.doe@example.com',22, 'Computer Science');
