using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using StudentModel = Student.Models.Student;
using Student.Data.Services;
using System.Collections.Generic;

namespace Student.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class StudentsController : ControllerBase
    {
        private readonly IStudentService _studentService;

        public StudentsController(IStudentService studentService)
        {
            _studentService = studentService;
        }

        [HttpGet]
        [AllowAnonymous]
        public ActionResult<IEnumerable<StudentModel>> GetAll()
        {
            return Ok(_studentService.GetAll());
        }

        [HttpGet("{id}")]
        public ActionResult<StudentModel> GetById(int id)
        {
            var student = _studentService.GetById(id);
            if (student is null) return NotFound();
            return Ok(student);
        }

        [HttpPost]
        public ActionResult<StudentModel> Create(StudentModel student)
        {
            var created = _studentService.Create(student);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }

        [HttpPut("{id}")]
        public ActionResult Update(int id, StudentModel updated)
        {
            var ok = _studentService.Update(id, updated);
            if (!ok) return NotFound();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var ok = _studentService.Delete(id);
            if (!ok) return NotFound();
            return NoContent();
        }
    }
}