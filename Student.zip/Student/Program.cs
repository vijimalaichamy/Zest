using System.Text;
using System.Security.Cryptography;
using System.Reflection;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Student.Middleware;
using Serilog;
using Student.Data.Repositories;
using Student.Data.Services;
using Student.Data.UnitOfWork;
using Student.Data;
using Microsoft.OpenApi.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Helper: decrypt encrypted connection from config using provided key
static string DecryptConnection(string encryptedBase64, string key)
{
    var cipher = Convert.FromBase64String(encryptedBase64);
    using var aes = Aes.Create();
    using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(key));
    aes.Key = hmac.ComputeHash(Encoding.UTF8.GetBytes(key)).Take(32).ToArray();
    var iv = new byte[aes.BlockSize / 8];
    Array.Copy(cipher, iv, iv.Length);
    using var ms = new MemoryStream(cipher, iv.Length, cipher.Length - iv.Length);
    using var cs = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read);
    using var sr = new StreamReader(cs, Encoding.UTF8);
    return sr.ReadToEnd();
}

// Configure Serilog early
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Debug()
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .WriteTo.File("Logs/log-.txt", rollingInterval: RollingInterval.Day)
    .CreateLogger();

builder.Host.UseSerilog();

// Add services to the container.
builder.Services.AddControllers();

//builder.Services.AddDbContext<StudentDbContext>(options =>
//    options.UseSqlServer());// (builder.Configuration.GetConnectionString("DefaultConnection")));

// Decrypt connection string if provided
var encrypted = builder.Configuration["EncryptedConnection"];
string connectionString;
if (!string.IsNullOrWhiteSpace(encrypted))
{
    // in real app, get the encryption key from secure store
    var decryptionKey = Environment.GetEnvironmentVariable("ENCRYPTION_KEY") ?? "ThisIsADevelopmentKeyDontUseInProduction";
    connectionString = DecryptConnection(encrypted, decryptionKey);
}
else
{
    var defaultCs = builder.Configuration.GetConnectionString("Default");
    connectionString = string.IsNullOrWhiteSpace(defaultCs) ? "Data Source=students.db" : defaultCs;
}

// Configure EF Core DbContext — use SQLite for local dev, SQL Server otherwise
bool isSqlite = connectionString.TrimStart().StartsWith("Data Source=", StringComparison.OrdinalIgnoreCase)
                && !connectionString.Contains("Server=", StringComparison.OrdinalIgnoreCase)
                && !connectionString.Contains("Initial Catalog=", StringComparison.OrdinalIgnoreCase);

builder.Services.AddDbContext<StudentDbContext>(options =>
{
    if (isSqlite)
        options.UseSqlite(connectionString);
    else
        options.UseSqlServer(connectionString);
});

// Register EF repository and EF UnitOfWork
builder.Services.AddScoped<IStudentRepository, EfStudentRepository>();
builder.Services.AddScoped<IUnitOfWork, EfUnitOfWork>();

// Register StudentService
builder.Services.AddScoped<IStudentService, StudentService>();
 
// Configure JWT authentication
var jwtSettings = builder.Configuration.GetSection("Jwt");
var key = Encoding.UTF8.GetBytes(jwtSettings["Key"] ?? "ThisIsADevelopmentKeyDontUseInProduction");

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = jwtSettings["Issuer"] ?? "MyApi",
        ValidAudience = jwtSettings["Audience"] ?? "MyApiUsers",
        IssuerSigningKey = new SymmetricSecurityKey(key)
    };
});

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    // Add JWT auth to swagger
    var securityScheme = new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Description = "Enter JWT Bearer token **_only_**",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        Reference = new OpenApiReference
        {
            Type = ReferenceType.SecurityScheme,
            Id = "Bearer"
        }
    };
    c.AddSecurityDefinition("Bearer", securityScheme);
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        { securityScheme, new[] { "Bearer" } }
    });

    // Include XML comments if available
    var xmlFile = Path.Combine(AppContext.BaseDirectory, (Assembly.GetExecutingAssembly().GetName().Name ?? "Student") + ".xml");
    if (File.Exists(xmlFile)) c.IncludeXmlComments(xmlFile);
});

var app = builder.Build();

// Use global exception handling middleware early in the pipeline
app.UseMiddleware<ExceptionHandlingMiddleware>();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.DisplayRequestDuration();
        // Add 'Authorize' button prominently
        c.EnablePersistAuthorization();
    });
}

//app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

// Ensure DB is created and apply migrations
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<StudentDbContext>();
    db.Database.Migrate();
}

app.Run();

// Ensure to flush and stop Serilog on shutdown
Log.CloseAndFlush();
