using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Student.Middleware
{
 public class ExceptionHandlingMiddleware
 {
 private readonly RequestDelegate _next;
 private readonly ILogger<ExceptionHandlingMiddleware> _logger;
 private readonly IWebHostEnvironment _env;

 public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger, IWebHostEnvironment env)
 {
 _next = next;
 _logger = logger;
 _env = env;
 }

 public async Task InvokeAsync(HttpContext context)
 {
 try
 {
 await _next(context);
 }
 catch (Exception ex)
 {
 _logger.LogError(ex, "Unhandled exception occurred while processing request");
 context.Response.ContentType = "application/json";
 context.Response.StatusCode = StatusCodes.Status500InternalServerError;

 var response = new ErrorResponse
 {
 Error = _env.IsDevelopment() ? ex.Message : "An unexpected error occurred.",
 StackTrace = _env.IsDevelopment() ? ex.StackTrace : null
 };

 var options = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
 await context.Response.WriteAsync(JsonSerializer.Serialize(response, options));
 }
 }
 }

 public class ErrorResponse
 {
 public string Error { get; set; } = string.Empty;
 public string? StackTrace { get; set; }
 }
}
