using StudentModel = Student.Models.Student;
using System.Collections.Generic;

namespace Student.Data.Services
{
 public interface IStudentService
 {
 IEnumerable<StudentModel> GetAll();
 StudentModel? GetById(int id);
 StudentModel Create(StudentModel student);
 bool Update(int id, StudentModel student);
 bool Delete(int id);
 }
}