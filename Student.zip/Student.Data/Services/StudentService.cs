using StudentModel = Student.Models.Student;
using Student.Data.Repositories;
using Student.Data.UnitOfWork;
using System.Collections.Generic;

namespace Student.Data.Services
{
 public class StudentService : IStudentService
 {
 private readonly IStudentRepository _repository;
 private readonly IUnitOfWork _unitOfWork;

 public StudentService(IStudentRepository repository, IUnitOfWork unitOfWork)
 {
 _repository = repository;
 _unitOfWork = unitOfWork;
 }

 public IEnumerable<StudentModel> GetAll() => _repository.GetAll();
 public StudentModel? GetById(int id) => _repository.GetById(id);
 public StudentModel Create(StudentModel student)
 {
 _unitOfWork.Begin();
 _repository.Add(student);
 _unitOfWork.Commit();
 return student;
 }
 public bool Update(int id, StudentModel student)
 {
 var existing = _repository.GetById(id);
 if (existing is null) return false;
 student.Id = id;
 _unitOfWork.Begin();
 _repository.Update(student);
 _unitOfWork.Commit();
 return true;
 }
 public bool Delete(int id)
 {
 var existing = _repository.GetById(id);
 if (existing is null) return false;
 _unitOfWork.Begin();
 _repository.Delete(id);
 _unitOfWork.Commit();
 return true;
 }
 }
}