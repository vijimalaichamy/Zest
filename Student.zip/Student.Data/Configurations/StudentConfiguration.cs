using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using StudentModel = Student.Models.Student;

namespace Student.Data.Configurations
{
 public class StudentConfiguration : IEntityTypeConfiguration<StudentModel>
 {
 public void Configure(EntityTypeBuilder<StudentModel> builder)
 {
 builder.ToTable("Students");

 builder.HasKey(e => e.Id);

 builder.Property(e => e.Name)
 .IsRequired()
 .HasMaxLength(200);

 builder.Property(e => e.Email)
 .IsRequired()
 .HasMaxLength(200);

 builder.HasIndex(e => e.Email).IsUnique();

 builder.Property(e => e.Age);

 builder.Property(e => e.Course)
 .HasMaxLength(200);

 builder.Property(e => e.CreatedDate)
 .HasConversion(v => v, v => DateTime.SpecifyKind(v, DateTimeKind.Utc))
 .HasDefaultValueSql("CURRENT_TIMESTAMP");
 }
 }
}