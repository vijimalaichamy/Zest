using StudentModel = Student.Models.Student;
using System.Collections.Generic;

namespace Student.Data.Repositories
{
 public interface IStudentRepository
 {
 IEnumerable<StudentModel> GetAll();
 StudentModel? GetById(int id);
 StudentModel Add(StudentModel student);
 void Update(StudentModel student);
 void Delete(int id);
 }
}