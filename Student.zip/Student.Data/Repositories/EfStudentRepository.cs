using StudentModel = Student.Models.Student;
using Microsoft.EntityFrameworkCore;
using Student.Data;

namespace Student.Data.Repositories
{
 public class EfStudentRepository : IStudentRepository
 {
 private readonly StudentDbContext _context;

 public EfStudentRepository(StudentDbContext context)
 {
 _context = context;
 }

 public IEnumerable<StudentModel> GetAll() => _context.Students.AsNoTracking().ToList();
 public StudentModel? GetById(int id) => _context.Students.AsNoTracking().FirstOrDefault(s => s.Id == id);
 public StudentModel Add(StudentModel student)
 {
 student.CreatedDate = DateTime.UtcNow;
 _context.Students.Add(student);
 return student;
 }
 public void Update(StudentModel student)
 {
 _context.Students.Update(student);
 }
 public void Delete(int id)
 {
 var student = _context.Students.Find(id);
 if (student is not null) _context.Students.Remove(student);
 }
 }
}