using Microsoft.EntityFrameworkCore.Storage;
using Student.Data;

namespace Student.Data.UnitOfWork
{
 public class EfUnitOfWork : IUnitOfWork
 {
 private readonly StudentDbContext _context;
 private IDbContextTransaction? _transaction;
 private bool _disposed;

 public EfUnitOfWork(StudentDbContext context)
 {
 _context = context;
 }

 public void Begin()
 {
 if (_transaction != null) return;
 _transaction = _context.Database.BeginTransaction();
 }

 public void Commit()
 {
 if (_transaction is null) return;
 _context.SaveChanges();
 _transaction.Commit();
 _transaction.Dispose();
 _transaction = null;
 }

 public void Rollback()
 {
 if (_transaction is null) return;
 _transaction.Rollback();
 _transaction.Dispose();
 _transaction = null;
 }

 public void Dispose()
 {
 if (_disposed) return;
 _transaction?.Dispose();
 _context.Dispose();
 _disposed = true;
 }
 }
}