namespace Student.Data.UnitOfWork
{
 public interface IUnitOfWork : IDisposable
 {
 void Begin();
 void Commit();
 void Rollback();
 }
}