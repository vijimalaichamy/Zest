using Microsoft.EntityFrameworkCore;
using StudentModel = Student.Models.Student;
using Student.Data.Configurations;

namespace Student.Data
{

 public class StudentDbContext : DbContext
 {
 public StudentDbContext(DbContextOptions<StudentDbContext> options) : base(options) { }

 public DbSet<StudentModel> Students { get; set; } = null!;

 protected override void OnModelCreating(ModelBuilder modelBuilder)
 {
 modelBuilder.ApplyConfiguration(new StudentConfiguration());
 }
 }
}