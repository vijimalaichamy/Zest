using System.Security.Cryptography;
using System.Text;

if (args.Length ==0)
{
 Console.WriteLine("Usage: Encryptor <plaintext> [key]");
 return;
}

string plaintext = args[0];
string key = args.Length >1 ? args[1] : "ThisIsADevelopmentKeyDontUseInProduction";

using var aes = Aes.Create();
using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(key));

aes.Key = hmac.ComputeHash(Encoding.UTF8.GetBytes(key)).Take(32).ToArray();
aes.GenerateIV();

using var ms = new MemoryStream();
// write IV first
ms.Write(aes.IV,0, aes.IV.Length);
using (var cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
using (var sw = new StreamWriter(cs, Encoding.UTF8))
{
 sw.Write(plaintext);
}

var cipher = Convert.ToBase64String(ms.ToArray());
Console.WriteLine(cipher);